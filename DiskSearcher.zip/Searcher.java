import java.io.File;
public class Searcher implements Runnable{
    private SynchronizedQueue<File> resultsQueue;
    private SynchronizedQueue<File> directoryQueue;
    private String prefix;
    private SynchronizedQueue<String> auditingQueue;
    private boolean isAudit;
    private int id;

    public Searcher(int id, String prefix, SynchronizedQueue<File> directoryQueue, SynchronizedQueue<File> resultsQueue, SynchronizedQueue<String> auditingQueue, boolean isAudit){
        super();
        this.prefix = prefix;
        this.directoryQueue = directoryQueue;
        resultsQueue.registerProducer();
        if (isAudit){
            auditingQueue.registerProducer();
        }
        this.resultsQueue = resultsQueue;
        this.isAudit = isAudit;
        this.auditingQueue = auditingQueue;
        this.id = id;
    }

    public void run(){
        try{
            while (true){
                File dir = this.directoryQueue.dequeue();
                if (dir != null){
                    File[] matchingFiles = dir.listFiles();
                    for (File f : matchingFiles){
                        if (f.isFile() && f.getName().startsWith(prefix)){
                            this.resultsQueue.enqueue(f);
                            if (this.isAudit){
                                this.auditingQueue.enqueue("Searcher on thread id " + this.id + ": file named " + f.getName() +" was found");
                            }
                        }
                    }
                }
                else{
                    break;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        this.resultsQueue.unregisterProducer();
        if (isAudit){
            this.auditingQueue.unregisterProducer();
        }
    }
}