import java.io.File;
import java.io.*;
public class Copier implements Runnable{
    private SynchronizedQueue<File> resultsQueue;
    private SynchronizedQueue<String> auditingQueue;
    private File destination;
    private int id;
    private boolean isAudit;
    public static final int COPY_BUFFER_SIZE = 4096;

    public Copier(int id, File destination, SynchronizedQueue<File> resultsQueue, SynchronizedQueue<String> auditingQueue, boolean isAudit) {
        super();
        this.resultsQueue = resultsQueue;
        this.auditingQueue = auditingQueue;
        this.destination = destination;
        this.id = id;
        this.isAudit = isAudit;
        if (isAudit){
            this.auditingQueue.registerProducer();
        }
    }

    public void run(){
        InputStream is = null; 
        OutputStream os = null;   
        File target = null;   
        File file;
        try{
            while ((file = this.resultsQueue.dequeue()) != null){
                target = new File(destination.getAbsolutePath(), file.getName());
                os = new FileOutputStream(target);
                is = new FileInputStream(file);
                int bytesRead;
                byte[] copyBuffer = new byte[COPY_BUFFER_SIZE];
                while ((bytesRead = is.read(copyBuffer)) > 0) { 
                    os.write(copyBuffer, 0, bytesRead);
                }
                if (this.isAudit){
                    this.auditingQueue.enqueue("Copier from thread id " + this.id + ": file named " + file.getName() +" was copied");
                }
                is.close();
                os.close();
            }
        }
        catch(Exception e){
            System.out.println("fff");
            e.printStackTrace();
        }
        if (isAudit){
            this.auditingQueue.unregisterProducer();
        }
    }
}