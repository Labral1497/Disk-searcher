import java.io.File;
public class Scouter implements Runnable{
    private SynchronizedQueue<File> directoryQueue;
    private  SynchronizedQueue<String> auditingQueue;
    private File rootDirectory;
    private boolean isAudit;
    private int id;

    public Scouter(int id, SynchronizedQueue<File> directoryQueue, File rootDirectory, SynchronizedQueue<String> auditingQueue, boolean isAudit) {
        super();
        directoryQueue.registerProducer();
        if (isAudit){
            auditingQueue.registerProducer();
        }
        this.directoryQueue = directoryQueue;
        this.rootDirectory = rootDirectory;
        this.isAudit = isAudit;
        this.auditingQueue = auditingQueue;
        this.id = id;
    }

    public void run(){
        /**
         * Helper class for recursion
         */
        class Helper {
            /**
             * Recursive directories locator
             * @param root a directory
             * @param directoryQueue the directory queue
             */
            private void recursiveRun(File root, SynchronizedQueue<File> directoryQueue, SynchronizedQueue<String> auditingQueue, int id){
                File[] files = root.listFiles();
                for (File file : files){
                    if (file.isDirectory()){
                        directoryQueue.enqueue(file);
                        if (isAudit){
                            auditingQueue.enqueue("Scouter on thread id " + id + ": directory named " + file.getName() + " was scouted");
                        }
                        recursiveRun(file, directoryQueue, auditingQueue, id);
                    }
                }
            }
        }
            if (isAudit){
                auditingQueue.enqueue("Scouter on thread id " + this.id + ": directory named " + this.rootDirectory.getName() + " was scouted");
            }
            this.directoryQueue.enqueue(rootDirectory);
            Helper obj = new Helper();
            obj.recursiveRun(this.rootDirectory, this.directoryQueue, this.auditingQueue, this.id);
            this.directoryQueue.unregisterProducer();
            if (isAudit){
                this.auditingQueue.unregisterProducer();
            }
    }
}
