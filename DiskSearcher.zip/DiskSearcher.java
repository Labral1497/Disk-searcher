import java.io.File;
public class DiskSearcher {
    public static final int AUDITING_QUEUE_CAPACITY = 50;
    public static final int DIRECTORY_QUEUE_CAPACITY = 50;
    public static final int RESULTS_QUEUE_CAPACITY = 50;
    public static void main(String[] args) {
        long start = System.nanoTime();
        if (args.length != 6){
            System.out.println("Number of arguments is not valid");
            return;
        }
        int threadId = 0;
        boolean isAudit;
        String prefix;
        File rootDir;
        File destDir;
        int numOfSearchers;
        int numOfCopiers;
        try{
            isAudit = Boolean.parseBoolean(args[0]);
            prefix = args[1];
            rootDir = new File(args[2]);
            destDir = new File(args[3]);
            numOfSearchers = Integer.parseInt(args[4]);
            numOfCopiers = Integer.parseInt(args[5]);
        }
        catch (Exception e){
            System.out.println("Invalid inputs");
            return;
        }
        SynchronizedQueue<String> auditingQueue;
        if (isAudit){
            auditingQueue = new SynchronizedQueue<>(AUDITING_QUEUE_CAPACITY);
            auditingQueue.enqueue("General, program has started the search");
        }
        else{
            auditingQueue = null;
        }
        SynchronizedQueue<File> directoryQueue = new SynchronizedQueue<>(DIRECTORY_QUEUE_CAPACITY);
        SynchronizedQueue<File> resultsQueue = new SynchronizedQueue<>(RESULTS_QUEUE_CAPACITY);
        Thread scouterThread = new Thread(new Scouter(++threadId, directoryQueue, rootDir, auditingQueue, isAudit));
        scouterThread.start();
        Thread[] searchers = new Thread[numOfSearchers];
        for (int i = 0 ; i < numOfSearchers ; i++){
            Thread searcher = new Thread(new Searcher(++threadId, prefix, directoryQueue, resultsQueue, auditingQueue, isAudit));
            searchers[i] = searcher;
            searcher.start();
        }
        // creat group of copiers
        Thread[] copiers = new Thread[numOfCopiers];
        for (int i = 0 ; i < numOfCopiers ; i++){
            Thread copier = new Thread(new Copier(++threadId, destDir, resultsQueue, auditingQueue, isAudit));
            copiers[i] = copier;
            copier.start();
        }
        // wait for scout to finish
        try {
            scouterThread.join();
        } catch (Exception e) {
            System.out.println("scouter problem");
            e.printStackTrace();
        }
        // wait for searchers and copiers to finish
        for (int i = 0 ; i < numOfSearchers ; i++){
            try {
                searchers[i].join();
            } catch (InterruptedException e) {
                System.out.println("searcher problem");
                e.printStackTrace();
            }
        }
        for (int i = 0 ; i < numOfCopiers ; i++){
            try {
                copiers[i].join();
            } catch (InterruptedException e) {
                System.out.println("copier problem");
                e.printStackTrace();
            }
        }
        double elapsedTime = (double) (System.nanoTime() - start);
        System.out.println("Total running time: " + elapsedTime + " seconds");
        int auditingQueueSize = auditingQueue.getSize();
        for (int i = 0; i < auditingQueueSize; i++){
            System.out.println(i+1 +": "+ auditingQueue.dequeue());
        }
    }
}
